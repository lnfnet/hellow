// Program 2.15 Characters and numbers 
#include <stdio.h>

int main(void)
{
  char first = 'T';
  char second = 63;

  printf("The first example as a letter looks like this - %c\n", first);
  printf("The first example as a number looks like this - %d\n", first);
  printf("The second example as a letter looks like this - %c\n", second);
  printf("The second example as a number looks like this - %d\n", second);
  return 0;
}
