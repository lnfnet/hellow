/* Program 1.3 Another Simple C Program - Displaying a Quotation */
#include <stdio.h>           // This is a preprocessor directive

int main(void)               // This identifies the function main()
{                            // This marks the beginning of main()
  printf("Beware the Ides of March!");  // This line outputs a quotation
  return 0;                  // This returns control to the operating system
}                            // This marks the end of main()


